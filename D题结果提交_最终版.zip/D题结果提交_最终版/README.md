# 支撑材料说明（2026 年中国研究生数学建模竞赛 D 题）

**参赛编号：26114150083**
**题目：山区洪涝灾害下无人机运输与通信协同优化**
**论文文件名：D26114150083.pdf**
**结果文件名：D题结果提交.xlsx**

本压缩包为论文的全部支撑材料，包含四问的可运行程序、中间结果、图件与原始赛题数据。所有论文正文中出现的数值结论均可在本包内追溯到具体文件，追溯对照表见同目录下的 **检查说明.md**。

---

## 一、目录结构

```
支撑材料/
├── README.md                      本文件：运行说明与目录导航
├── 检查说明.md                     论文数值 → 源文件的逐项核验清单
├── 结果索引.xlsx                   论文表/图 → 数据文件 → 生成脚本 的机读索引
│
├── 原始赛题数据/                   赛题方提供的原始数据（未作任何修改）
│   ├── 无人机应急物资运输基础数据/
│   │   ├── 调度中心与服务区.xlsx
│   │   ├── 物资需求与配送时限.xlsx
│   │   ├── 运输无人机数据.xlsx
│   │   ├── 中继无人机数据.xlsx
│   │   └── 通信链路参数.xlsx
│   └── 镇龙乡地理空间数据/
│       ├── 镇龙乡及周边地理数据/
│       │   ├── 数字高程模型数据（DEM）/镇龙乡及周边30米DEM.tif
│       │   ├── 村镇点位/、道路/、水系（线）/、水体（面）/
│       ├── 镇龙乡地理空间数据说明.pdf
│       └── 镇龙乡地理空间详情地图.html
│
├── 问题一_代码/                    Q1 单点组批与能耗核算
│   ├── main.py                    统一入口（含环境自检）
│   ├── config.py                  路径与数据源配置（运行前需改 PROBLEM_ROOT）
│   ├── q1_solution.py             组批求解主逻辑
│   ├── q1_validate.py             结果独立复核
│   ├── q1_figures.py              论文插图生成
│   ├── q1_payload_reserve_sensitivity.py   载重/余量灵敏度分析
│   └── 扩展绘图/                   generate_paper_figures.py、generate_altitude_figures.py
│
├── 问题二_代码与结果/              Q2 多机多电池调度（最终采用方案）
│   ├── python代码/                23 个脚本，核心见下文"三、复现步骤"
│   ├── matlab代码/                q2_main.m、q2_baseline.m、run_all.m、q2_code_plan.md
│   └── 结果/
│       ├── dispatch.csv           ★ 论文表 6.8 的权威数据源（23 架次）
│       ├── delivery.csv           逐箱交付明细（80 箱）
│       ├── models.csv             机型分配
│       ├── q2_dispatch_independent_audit.json   独立审计结论
│       ├── q2_*_validation.json   约束可行性校验
│       ├── q2_ecef_3d_distance_matrix_m.csv     三维距离矩阵
│       ├── q2_dem_peak_audit.csv  DEM 沿航线峰值与净空校核
│       └── 历史版本（未采用）/     早期 25 架次方案，仅留档，论文未引用
│
├── 问题三_代码与结果/              Q3 运输—通信联合优化
│   ├── 代码/                      12 个脚本，联合优化入口为 问题三_V3_联合优化.py
│   ├── 结果/
│   │   ├── 问题三_时间主方案_结果.json          ★ Q3 汇总指标
│   │   ├── 问题三_时间主方案_运输_架次.csv      22 条运输架次
│   │   ├── 问题三_时间主方案_运输_逐箱.csv      80 箱交付
│   │   ├── 问题三_时间主方案_精确_通信保障.csv  280 条通信区段
│   │   ├── 问题三_时间主方案_精确_连续通信复核.json  零中断复核
│   │   └── 问题三_时间主方案_V3_独立核验.json   独立核验
│   └── 图件/                      论文第 7 章插图
│
├── 问题四_代码与结果/              Q4 多分区资源配置
│   ├── 代码/                      17 个脚本，主求解为 compute_q4_cpsat.py
│   ├── 结果/
│   │   ├── results.json           ★ Q4 汇总（K=2 / K=3 方案与缺口）
│   │   ├── q4_cpsat_solution.csv  CP-SAT 分区解
│   │   ├── q4_cpsat_certificate.json  最优性证书
│   │   ├── group_resources.csv    各组资源需求（论文表 8.12/8.13）
│   │   ├── q4_hypergraph_edges.csv / must_link_edges.csv   任务超图与必连边
│   │   └── q4_fairness_lower_bound.csv   公平性下界
│   └── 图件/                      论文第 8 章插图
│
└── 源码/                          Q3/Q4 的工程化源码包（模块级实现）
    ├── src_q3/                    库代码：链路预算、地形遮挡、CP-SAT 调度、ALNS 等
    │   └── q3/                    relay / communication / transport 子模块
    ├── 入口与测试/                 Q3.py、Q4.py、Q3_step3~step13、单元测试与设计文档
    │   ├── Q3_alns.md、Q3_relay_master_cuts.md   算法设计说明
    │   └── Q4_model.md、Q4_precompute.md、Q4_术语表格.md、Q4_题目分析报告.md
    └── 关键冻结结果/               Q3→Q4 传递用的冻结中间态（含早期迭代版本）
```

---

## 二、运行环境

| 项 | 版本要求 |
|---|---|
| 操作系统 | Windows 10/11 或 macOS 均可（开发环境为 Windows） |
| Python | 3.10 – 3.12（开发环境 3.12） |
| MATLAB | R2021b 及以上（仅 `问题二_代码与结果/matlab代码/` 需要，可选） |

Python 依赖：

```bash
pip install numpy pandas scipy openpyxl matplotlib pillow networkx rasterio pyproj ortools
```

其中：

- `ortools`：CP-SAT 求解器，Q2/Q3/Q4 的调度与分区模型依赖，建议 ≥ 9.7
- `rasterio` + `pyproj`：读取 30 m DEM、做 WGS84 ↔ ECEF/ENU 坐标转换
- `openpyxl`：读取赛题 xlsx 与写出结果提交表
- `networkx`：Q4 任务超图连通分量与必连边处理

`问题一_代码/main.py` 内置环境自检，可先执行：

```bash
python main.py --check-env
```

---

## 三、复现步骤

> **运行前必须先改路径。** `问题一_代码/config.py` 第 5 行的 `PROBLEM_ROOT` 为开发机的绝对路径 `D:\26数学建模\D题`，请改为本压缩包解压后 `原始赛题数据/` 的上级目录，例如：
>
> ```python
> PROBLEM_ROOT = Path(__file__).resolve().parent.parent / "原始赛题数据"
> ```
>
> 其余三问的脚本以相对路径读写同目录 `结果/`，解压后可直接运行。

### 问题一

```bash
cd 问题一_代码
python main.py                       # 求解 + 导出 outputs/
python q1_validate.py                # 独立复核（载重、体积、能量、SOC 下界）
python q1_figures.py                 # 论文第 5 章插图
python q1_payload_reserve_sensitivity.py   # 安全余量灵敏度
```

### 问题二

```bash
cd 问题二_代码与结果/python代码
python spatial_preprocess.py         # DEM 采样 → 三维距离矩阵、巡航海拔
python solve_q2_baseline.py          # 可行基准解
python improve_q2_route_order.py     # 路径顺序改进
python optimize_q2_combined.py       # ★ 最终采用方案，产出 结果/dispatch.csv
python package_q2_dispatch.py        # 打包为提交表格式
python audit_dem_clearance.py        # DEM 净空独立审计
```

MATLAB 路线（可选，用于交叉验证）：

```matlab
cd 问题二_代码与结果/matlab代码
run_all            % 依次调用 q2_baseline.m、q2_main.m
```

### 问题三

```bash
cd 问题三_代码与结果/代码
python 问题三_通信几何.py            # 链路预算 + 地形遮挡判定
python 问题三_V3_联合优化.py         # ★ 运输—中继联合调度，产出 结果/问题三_时间主方案_*.csv
python 问题三_V3_通信状态.py         # 逐架次通信区段展开（280 条）
python 问题三_V3_结果核验.py         # 零中断 / 零硬截止违约核验
python 问题三_V4_地图绘图.py         # 论文第 7 章地图
python 问题三_V7_六面板三维山地航线.py   # 三维航线图
```

模块级源码路线（与上等价，工程化封装）：

```bash
cd 源码
python 入口与测试/Q3.py              # 端到端 Q3
python -m pytest 入口与测试/test_q3_*.py   # 单元测试
```

### 问题四

```bash
cd 问题四_代码与结果/代码
python compute_q4.py                 # 任务超图 + 连通分量 + 必连边
python compute_q4_spatial.py         # 空间紧凑度与椭圆包络
python compute_q4_cpsat.py           # ★ CP-SAT 分区与资源配置，产出 结果/results.json
python compute_q4_no_singletons.py   # 不设单站组的扩展场景
python plot_q4_final_answer.py       # 论文第 8 章主图
python plot_q4_maps.py               # 分区地图
```

---

## 四、核心结果速查

| 问题 | 关键指标 | 数值 | 源文件 |
|---|---|---|---|
| Q1 | 架次数 / 货箱数 / 总质量 | 18 架次 / 80 箱 / 758 kg | `D题结果提交.xlsx` → `Q1_单点组批` |
| Q1 | 总能耗 / 最低返航 SOC | 59.132 kWh / 23.088 % | 同上 |
| Q2 | 架次数（A/B/C） | 23（10 / 7 / 6） | `问题二_代码与结果/结果/dispatch.csv` |
| Q2 | 资源投入 | 8 架运输无人机 + 14 组电池 | 同上（`drone_id` / `battery_id` 去重） |
| Q2 | 完工时刻 Cmax | 6195.959 s（103.27 min） | 同上（`return_s` 最大值） |
| Q2 | 总能耗 / 最低返航 SOC | 69.738087 kWh / 20.242 % | 同上（`energy_kwh` 求和 / `return_soc` 最小值） |
| Q3 | 运输架次 + 中继架次 | 22 + 4 | `问题三_代码与结果/结果/问题三_时间主方案_结果.json` |
| Q3 | 联合完工时刻 | 6936 s | 同上 `joint_finish_s` |
| Q3 | 总能耗（运输 + 中继） | 66.215521 kWh（63.541585 + 2.673936） | 同上 |
| Q3 | 通信中断次数 / 硬截止违约 | 0 / 0 | 同上 `communication_coverage_failures`、`weighted_lateness` |
| Q4 | K=2 资源缺口 | 5 件 | `问题四_代码与结果/结果/results.json` |
| Q4 | K=3 资源缺口 | 9 件 | 同上 |

逐项核验方法见 **检查说明.md**。

---

## 五、说明事项

1. **随机性与可复现性**：Q3 的 ALNS 搜索、Q4 的候选枚举均已固定随机种子；CP-SAT 在多线程下可能返回不同的等价最优解，但目标值（Cmax、能耗、缺口数）稳定一致。论文所引数值以本包 `结果/` 目录内已冻结的 CSV/JSON 为准。
2. **历史版本留档**：`问题二_代码与结果/结果/历史版本（未采用）/` 内的两份 25 架次方案为中期迭代产物，论文未采用，仅作优化过程佐证保留。若与论文数值不一致，一律以 `dispatch.csv` 为准。
3. **源码/关键冻结结果/** 中的部分文件（如 `q3_joint_relay_schedule.csv`）为 Q3 中期迭代的冻结快照，用于向 Q4 传递结构信息，其数值不代表论文最终结论；Q3 最终结论见 `问题三_代码与结果/结果/`。
4. **原始数据未作改动**，`原始赛题数据/` 与赛题下发文件逐字节一致（DEM 的 `.mat` 副本因与 `.tif` 内容重复未纳入，以减小压缩包体积）。
5. **图件的体积处理**：论文正文已内嵌全部插图的高分辨率原版，本支撑包内的 `图件/` 仅作对照留存，故作了如下精简——（a）删除三组内容完全相同、仅文件名不同的重复副本（经 MD5 校验一致）；（b）删除与 PNG 同图的 PDF 副本及低分辨率预览图；（c）将 600 dpi 的超大图统一降采样至 2600 px 宽并做调色板优化。图件的**数量、内容与结论均未改变**，仅降低了存储分辨率。如需原始分辨率图件，运行各问 `代码/` 目录下的 `plot_*.py` 即可按原参数重新生成。
